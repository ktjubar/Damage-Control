<?php

// path constants
define('SYSTEM_PATH', dirname(__FILE__)); # location of 'app' folder - don't change
define('BASE_URL', 'http://localhost/cs3744/project4/DamageControl'); # your base URL

define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_HOST', 'localhost');
define('DB_DATABASE', '8thAirforce');
